# Changelog

## 1.0.0
- Initial public release as **Mic Router Lite** (`com.microuter.lite`), a
  clean rebuild replacing an earlier prototype.
- Dropdown selection of any connected microphone (built-in, wired, USB,
  Bluetooth), live-updating as devices connect/disconnect.
- Foreground service holds routing via `setCommunicationDevice` (API 31+),
  `AudioRecord.setPreferredDevice`, and Bluetooth SCO where applicable.
- Live diagnostics log and mic level meter.
- Removed an earlier experimental "force audio output device" feature —
  Android generally pairs one mic with one speaker for calls, so forcing
  input and output to two different physical devices independently isn't
  reliably supported by the OS and added complexity without a dependable
  payoff.
- Release build enables ProGuard/R8 minification.
