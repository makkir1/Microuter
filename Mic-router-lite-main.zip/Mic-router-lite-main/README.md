# Mic Router Lite

Force Android to use a specific microphone — your phone's built-in mic, a wired
headset, USB, or Bluetooth — instead of whatever the system picks automatically
when a headset is plugged in. Built for the common case of wanting your
**phone's mic** while wearing **wired earphones with no mic** during gaming,
without touching the game itself.

![Android](https://img.shields.io/badge/platform-Android%2010%2B-3DDC84)
![License: MIT](https://img.shields.io/badge/license-MIT-blue)
[![Android Build](../../actions/workflows/android-build.yml/badge.svg)](../../actions/workflows/android-build.yml)

---

## ⚠️ Read this before you build

Android does **not** give normal, non-root apps a supported way to force
*another app's* microphone input. This app uses the strongest APIs available
to a regular app (`AudioManager.setCommunicationDevice`,
`AudioRecord.setPreferredDevice`, Bluetooth SCO) to *nudge* the system's audio
routing. On some phones and some apps/games this genuinely works. On others —
especially games with their own native audio engines, and on newer Android
versions with tighter mic restrictions — it may have no effect at all.

**This is not a bug you can code around from userspace.** If it doesn't work
for your game, your only fully reliable options are:
- A cheap 3-pole (no-mic) cable, or a mic-blocking adapter — Android falls
  back to the built-in mic automatically. Free trick: cover the mic ring on a
  4-pole plug with tape or a dab of nail polish.
- Rooting with Magisk and patching the audio policy directly.

The app includes a **live log** so you can see exactly what actually
happened, rather than guessing.

## Features

- Live list of every connected microphone (built-in, wired, USB, Bluetooth) in
  a dropdown — updates automatically as you plug/unplug devices, or tap
  **Refresh**.
- One tap to force the phone's built-in mic (or any other connected input).
- Runs as a foreground service so routing is kept in place while you play.
- Live log panel showing:
  - Every input device detected, with its Android device type.
  - Whether `setCommunicationDevice` was accepted by the system.
  - Bluetooth SCO connection attempts.
  - Which device *your own recording stream* actually landed on.
  - Which device *any other app's* active recording (e.g. your game's voice
    chat) is using — this is the real test of whether it worked.
- A live level meter so you can visually confirm the forced mic is picking up
  sound.

## How it works

1. `AudioManager.setCommunicationDevice()` (Android 12+) tells the system
   which device should carry call/VoIP-style audio.
2. In parallel, the app opens its own `AudioRecord` session pinned to the
   chosen device with `setPreferredDevice()`. This proves the mechanism works
   and can help nudge routing on some OEM audio stacks.
3. For Bluetooth targets, the app starts Bluetooth SCO explicitly, since a
   Bluetooth mic won't carry audio without it.
4. Everything is re-applied automatically whenever a device is plugged,
   unplugged, or you pick a different one from the dropdown.

## Permissions

| Permission | Why |
|---|---|
| `RECORD_AUDIO` | Required to open the internal recording session used to hold routing and show the level meter. |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE` | Lets the routing stay active while you switch to your game. |
| `MODIFY_AUDIO_SETTINGS` | Needed for `setCommunicationDevice` / Bluetooth SCO calls. |
| `BLUETOOTH_CONNECT` | Needed to read Bluetooth device names and start SCO audio (Android 12+). |

No data leaves the device. Nothing is recorded to disk. Audio is read only to
compute the live level meter and immediately discarded.

## Build

Requires JDK 17+ (JDK 21 works fine) and the Android SDK (`platforms;android-34`,
`build-tools;34.0.0`).

```bash
git clone <your-repo-url>
cd mic-router-lite
./gradlew assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

Easiest path: open the project folder in **Android Studio** and press **Run**.

No local SDK? Push to GitHub and let the included Actions workflow
(`.github/workflows/android-build.yml`) build it for you — every push and pull
request produces a downloadable `mic-router-lite-debug` artifact under the
**Actions** tab.

## Install

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

or copy the APK to your phone and open it (you'll need to allow installs from
unknown sources for your file manager / browser).

## Usage

1. Open the app, grant the microphone (and Bluetooth, if prompted) permission.
2. Plug in your headset / connect your Bluetooth device.
3. Pick the input you want to force from the **Microphone input** dropdown.
4. Tap **Start**.
5. Open your game and start voice chat.
6. Check the log: look for a line like
   `App recording: VOICE_COMMUNICATION -> Phone microphone`. If it says the
   device you picked, it worked for that game. If it still shows your
   headset's mic, this approach isn't effective for that particular game on
   your phone.

## Troubleshooting

- **No devices shown**: tap Refresh. If still empty, your earphones may not
  have a working mic — Android only lists devices with a mic as an input
  (check for a 4-pole/TRRS plug).
- **App crashes on launch**: please open an issue with the crash log
  (`adb logcat *:E | grep -i AndroidRuntime` right after it crashes) — a
  `FATAL EXCEPTION` block pinpoints the exact line.
- **Log shows the right device, but the game doesn't sound right**: that's
  expected on some titles — the OS reports where audio is routed, but a game
  can still apply its own signal processing regardless.

## Contributing

Issues and PRs welcome — especially reports of which phones/games this does
and doesn't work for, so the README's expectations stay honest.

## License

[MIT](LICENSE)
