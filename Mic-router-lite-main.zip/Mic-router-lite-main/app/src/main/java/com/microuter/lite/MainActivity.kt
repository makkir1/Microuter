package com.microuter.lite

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var am: AudioManager
    private lateinit var micSpinner: Spinner
    private lateinit var toggleBtn: Button
    private lateinit var level: ProgressBar
    private lateinit var logView: TextView
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var scroll: ScrollView

    private var micDevices: List<AudioDeviceInfo> = emptyList()
    private var selectedMicId = -1
    private var selectedMicType = AudioDeviceInfo.TYPE_BUILTIN_MIC
    private var running = false
    private var suppressSpinnerEvents = false

    private val uiHandler = Handler(Looper.getMainLooper())

    // Keeps the dropdown live while the app is open, independent of whether the
    // background service is running.
    private val liveDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) {
            Logger.log("Detected connected: " + added.joinToString { typeName(it.type) })
            uiHandler.post { refreshDevices() }
        }
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) {
            Logger.log("Detected disconnected: " + removed.joinToString { typeName(it.type) })
            uiHandler.post { refreshDevices() }
        }
    }

    private val plugReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { uiHandler.post { refreshDevices() } }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        am = getSystemService(AudioManager::class.java)

        micSpinner = findViewById(R.id.micSpinner)
        toggleBtn = findViewById(R.id.toggleBtn)
        level = findViewById(R.id.level)
        logView = findViewById(R.id.logView)
        statusText = findViewById(R.id.statusText)
        statusDot = findViewById(R.id.statusDot)
        scroll = (logView.parent as ScrollView)

        running = MicRouteService.isRunning
        setStatus(running, if (running) "Running" else "Not running")

        refreshDevices()
        findViewById<TextView>(R.id.refreshBtn).setOnClickListener {
            Logger.log("Manual refresh tapped")
            refreshDevices()
        }

        micSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (suppressSpinnerEvents) return
                val d = micDevices.getOrNull(pos) ?: return
                selectedMicId = d.id; selectedMicType = d.type
                Logger.log("Mic target selected: ${typeName(d.type)}")
                if (running) sendMicTarget()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        synchronized(Logger.lines) { logView.text = Logger.lines.joinToString("\n") }
        Logger.onLog = { l -> runOnUiThread { logView.append("\n$l"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } } }
        Logger.onLevel = { v -> runOnUiThread { level.progress = v } }
        Logger.onStatus = { r, t -> runOnUiThread { running = r; setStatus(r, t); toggleBtn.text = if (r) "Stop" else "Start" } }

        toggleBtn.text = if (running) "Stop" else "Start"
        toggleBtn.setOnClickListener {
            if (!ensurePermissions()) return@setOnClickListener
            if (!running) {
                if (selectedMicId == -1) { Toast.makeText(this, "Pick a microphone first", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                startForegroundService(Intent(this, MicRouteService::class.java))
                sendMicTarget()
                toggleBtn.background = getDrawable(R.drawable.btn_stop)
            } else {
                startService(Intent(this, MicRouteService::class.java).setAction(MicRouteService.ACTION_STOP))
                toggleBtn.background = getDrawable(R.drawable.btn_primary)
                level.progress = 0
            }
        }
    }

    private fun setStatus(r: Boolean, t: String) {
        statusText.text = t
        statusDot.setBackgroundResource(if (r) R.drawable.dot_good else R.drawable.dot_idle)
    }

    private fun sendMicTarget() {
        val i = Intent(this, MicRouteService::class.java).setAction(MicRouteService.ACTION_SET_TARGET)
            .putExtra(MicRouteService.EXTRA_DEVICE_ID, selectedMicId)
            .putExtra(MicRouteService.EXTRA_DEVICE_TYPE, selectedMicType)
        startForegroundService(i)
    }

    private fun currentInputs(): List<AudioDeviceInfo> = try {
        am.getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.isSource }.distinctBy { it.type }
    } catch (e: Exception) { Logger.log("Device query error: ${e.message}"); emptyList() }

    private fun labelFor(d: AudioDeviceInfo): String {
        val nice = try { d.productName?.toString()?.takeIf { it.isNotBlank() && it != "Built-in" } }
            catch (e: Exception) { null }
        return "${iconFor(d.type)}  ${nice ?: typeName(d.type)}"
    }

    private fun refreshDevices() {
        micDevices = currentInputs()
        Logger.log("Refresh: ${micDevices.size} input device(s) — " + if (micDevices.isEmpty()) "none" else micDevices.joinToString { "${typeName(it.type)}(${it.type})" })

        suppressSpinnerEvents = true
        val labels = if (micDevices.isEmpty()) listOf("No microphones detected") else micDevices.map { labelFor(it) }
        micSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        if (micDevices.isNotEmpty()) {
            var idx = micDevices.indexOfFirst { it.id == selectedMicId }
            if (idx < 0) idx = micDevices.indexOfFirst { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }.takeIf { it >= 0 } ?: 0
            micSpinner.setSelection(idx)
            selectedMicId = micDevices[idx].id; selectedMicType = micDevices[idx].type
        }
        suppressSpinnerEvents = false
    }

    override fun onResume() {
        super.onResume()
        try { am.registerAudioDeviceCallback(liveDeviceCallback, uiHandler) } catch (e: Exception) { Logger.log("Callback register failed: ${e.message}") }
        try { registerReceiver(plugReceiver, IntentFilter(AudioManager.ACTION_HEADSET_PLUG)) } catch (e: Exception) {}
        refreshDevices()
    }

    override fun onPause() {
        super.onPause()
        try { am.unregisterAudioDeviceCallback(liveDeviceCallback) } catch (e: Exception) {}
        try { unregisterReceiver(plugReceiver) } catch (e: Exception) {}
    }

    private fun ensurePermissions(): Boolean {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.BLUETOOTH_CONNECT
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return false }
        return true
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 1 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            toggleBtn.performClick()
        } else if (results.any { it != PackageManager.PERMISSION_GRANTED }) {
            Toast.makeText(this, "Mic permission is required to run this", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Logger.onLog = null; Logger.onLevel = null; Logger.onStatus = null
        super.onDestroy()
    }
}
