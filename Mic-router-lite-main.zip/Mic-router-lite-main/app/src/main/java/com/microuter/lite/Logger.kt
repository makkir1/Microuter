package com.microuter.lite

import android.media.AudioDeviceInfo
import java.text.SimpleDateFormat
import java.util.*

object Logger {
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    val lines = ArrayDeque<String>()
    @Volatile var onLog: ((String) -> Unit)? = null
    @Volatile var onLevel: ((Int) -> Unit)? = null
    @Volatile var onStatus: ((Boolean, String) -> Unit)? = null

    fun log(m: String) {
        val l = "${fmt.format(Date())}  $m"
        synchronized(lines) { lines.addLast(l); if (lines.size > 300) lines.removeFirst() }
        onLog?.invoke(l)
    }
}

fun typeName(t: Int): String = when (t) {
    AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Phone microphone"
    AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired earphones (mic)"
    AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired headphones"
    AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
    AudioDeviceInfo.TYPE_USB_DEVICE -> "USB audio device"
    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth headset"
    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (A2DP)"
    AudioDeviceInfo.TYPE_TELEPHONY -> "Telephony"
    AudioDeviceInfo.TYPE_FM_TUNER -> "FM tuner"
    else -> "Device (type $t)"
}

fun iconFor(t: Int): String = when (t) {
    AudioDeviceInfo.TYPE_BUILTIN_MIC -> "📱"
    AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "🎧"
    AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> "🔌"
    AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "📶"
    else -> "🎤"
}

fun srcName(s: Int) = when (s) {
    1 -> "MIC"; 5 -> "CAMCORDER"; 6 -> "VOICE_RECOGNITION"
    7 -> "VOICE_COMMUNICATION"; 9 -> "UNPROCESSED"; else -> "src=$s"
}
