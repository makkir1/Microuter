package com.microuter.lite

import android.app.*
import android.content.*
import android.media.*
import android.os.*
import kotlin.math.log10
import kotlin.math.sqrt

class MicRouteService : Service() {
    companion object {
        const val ACTION_SET_TARGET = "com.microuter.lite.SET_TARGET"
        const val ACTION_STOP = "com.microuter.lite.STOP"
        const val EXTRA_DEVICE_ID = "device_id"
        const val EXTRA_DEVICE_TYPE = "device_type"
        var isRunning = false
    }

    private lateinit var am: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private var record: AudioRecord? = null
    @Volatile private var recording = false
    private var targetId = -1
    private var targetType = AudioDeviceInfo.TYPE_BUILTIN_MIC

    private val plugReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            Logger.log("Device change detected (plug/unplug) — re-applying target")
            applyRouting()
        }
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) {
            Logger.log("Connected: " + added.filter { it.isSource }.joinToString { typeName(it.type) })
            applyRouting()
        }
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) {
            Logger.log("Disconnected: " + removed.filter { it.isSource }.joinToString { typeName(it.type) })
            applyRouting()
        }
    }

    private val recCb = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: List<AudioRecordingConfiguration>) {
            configs.forEach {
                val dev = it.audioDevice
                Logger.log("App recording: ${srcName(it.clientAudioSource)} -> ${dev?.let { d -> typeName(d.type) } ?: "unknown"}")
            }
        }
    }

    override fun onCreate() {
        am = getSystemService(AudioManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mic", "Mic Router Lite", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, buildNotif("Starting…"))
        registerReceiver(plugReceiver, IntentFilter(AudioManager.ACTION_HEADSET_PLUG))
        am.registerAudioDeviceCallback(deviceCallback, handler)
        am.registerAudioRecordingCallback(recCb, handler)
        Logger.log("Service created")
        isRunning = true
        Logger.onStatus?.invoke(true, "Running")
    }

    private fun buildNotif(text: String): Notification =
        Notification.Builder(this, "mic").setContentTitle("Mic Router Lite active")
            .setContentText(text).setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_SET_TARGET -> {
                targetId = i.getIntExtra(EXTRA_DEVICE_ID, -1)
                targetType = i.getIntExtra(EXTRA_DEVICE_TYPE, AudioDeviceInfo.TYPE_BUILTIN_MIC)
                applyRouting()
            }
        }
        return START_STICKY
    }

    private fun applyRouting() {
        val inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val target = inputs.firstOrNull { it.id == targetId }
            ?: inputs.firstOrNull { it.type == targetType }
            ?: inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
        if (target == null) { Logger.log("ERROR: target device not found among ${inputs.size} inputs"); return }

        Logger.log("Target -> ${typeName(target.type)} (id ${target.id})")

        // Strong mechanism (API 31+): tells the system this is the device for
        // communication-mode audio (calls / VoIP). Wider effect than our own stream alone.
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val ok = am.setCommunicationDevice(target)
                Logger.log("setCommunicationDevice -> ${if (ok) "accepted" else "rejected by system"}")
            } catch (e: Exception) { Logger.log("setCommunicationDevice failed: ${e.message}") }
        }

        // Bluetooth needs SCO explicitly started to actually carry mic audio.
        if (target.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
            try {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                am.startBluetoothSco()
                am.isBluetoothScoOn = true
                Logger.log("Bluetooth SCO requested")
            } catch (e: Exception) { Logger.log("Bluetooth SCO failed: ${e.message}") }
        } else {
            try { am.stopBluetoothSco(); am.isBluetoothScoOn = false } catch (_: Exception) {}
        }

        startInternalRecording(target)
        startForeground(1, buildNotif("Forcing: ${typeName(target.type)}"))
    }

    // Our own always-on recording — proof it works, and helps nudge routing on some devices.
    private fun startInternalRecording(target: AudioDeviceInfo) {
        stopRecording()
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) { Logger.log("Recording error: device doesn't support this format"); return }
        try {
            val r = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
            r.setPreferredDevice(target)
            r.addOnRoutingChangedListener(AudioRouting.OnRoutingChangedListener { ar ->
                Logger.log("Our stream actually routed to: ${(ar as AudioRecord).routedDevice?.let { typeName(it.type) } ?: "none"}")
            }, handler)
            r.startRecording()
            record = r
            recording = true
            // Larger read chunks than the min buffer reduces wakeups/CPU for the
            // level meter without adding noticeable latency.
            Thread {
                val b = ShortArray(2048)
                var tick = 0
                while (recording) {
                    val n = try { r.read(b, 0, b.size) } catch (e: Exception) { -1 }
                    if (n != null && n > 0) {
                        tick++
                        if (tick % 2 == 0) { // update the UI meter at ~half rate, plenty smooth
                            var s = 0.0
                            for (k in 0 until n) s += b[k] * b[k].toDouble()
                            val db = 20 * log10(sqrt(s / n) + 1)
                            Logger.onLevel?.invoke((db / 90 * 100).toInt().coerceIn(0, 100))
                        }
                    } else break
                }
            }.start()
        } catch (e: Exception) {
            Logger.log("Recording error: ${e.message}")
        }
    }

    private fun stopRecording() {
        recording = false
        record?.run { try { stop() } catch (_: Exception) {}; release() }
        record = null
    }

    override fun onDestroy() {
        stopRecording()
        if (Build.VERSION.SDK_INT >= 31) try { am.clearCommunicationDevice() } catch (_: Exception) {}
        try { am.stopBluetoothSco(); am.isBluetoothScoOn = false } catch (_: Exception) {}
        am.unregisterAudioDeviceCallback(deviceCallback)
        am.unregisterAudioRecordingCallback(recCb)
        unregisterReceiver(plugReceiver)
        isRunning = false
        Logger.onStatus?.invoke(false, "Stopped")
        Logger.log("Service stopped")
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
